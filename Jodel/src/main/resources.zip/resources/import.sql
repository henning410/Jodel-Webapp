-- Some initial data
INSERT INTO user (user_id, password, username) VALUES(2, "1234", "moruit00");
INSERT INTO user (user_id, password, username) VALUES(1, "1234", "heweit00");

INSERT INTO post (post_id, latitude, longitude, postdate, text, user_id) VALUES(1, 48.65131741698757, 9.44329696733342, "2019-06-03", "Ich hasse es es, wenn mich jemand weckt und sagt: Los aufstehen, die Sonne scheint schon. Was soll ich denn machen? Fotosynthese??", 1);
INSERT INTO post (post_id, latitude, longitude, postdate, text, user_id) VALUES (2, 48.7123069997825, 9.417232564186753, "2019-06-03", "Die Klausur war so gut, die schreib ich direkt nochmal", 2);
--create post with location somewhere in Bielefeld, to test that it is not showing here in Stuttgart
INSERT INTO post (post_id, latitude, longitude, postdate, text, user_id) VALUES(3, 52.068578992453254,  8.46197772962304, "2019-06-02", "Wenn du ein S wärst, dann wärst du ein ß", 2);

INSERT INTO comment (comment_id, latitude, longitude, text, post_id, user_id) VALUES (1, 48.7449668231042, 9.321958266147778, "das ist ja mal ein guter Spruch", 1, 2);
INSERT INTO comment (comment_id, latitude, longitude, text, post_id, user_id) VALUES (2, 48.757701831303415, 9.377853724703542, "Ja ich hätte lernen können aber heeeyyy, 4 gewinnt", 2, 2);
INSERT INTO comment (comment_id, latitude, longitude, text, post_id, user_id) VALUES (3, 48.75610384297406, 9.189483608988407, "Draußen vom Prüfer da komme ich her, ich muss euch sagen, ich weine jetzt sehr. Für die Uni zu blöd, zum strippen zu fett, leck mich am Ars***, ich gehe jetzt ins Bett!", 2, 2);

INSERT INTO voting (voting_id, value, comment_id) VALUES (1, 1, 1);
INSERT INTO voting (voting_id, value, comment_id) VALUES (2, 3, 2);
INSERT INTO voting (voting_id, value, comment_id) VALUES (3, 2, 3);